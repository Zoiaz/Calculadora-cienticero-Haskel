module Main where

main :: IO ()
main = putStrLn "¡Hola desde Haskell!"
